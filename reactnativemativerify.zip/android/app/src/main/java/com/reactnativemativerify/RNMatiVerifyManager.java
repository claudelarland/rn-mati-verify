package com.reactnativemativerify;

import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.View;
import android.widget.Toast;

import com.facebook.react.uimanager.SimpleViewManager;
import com.facebook.react.uimanager.ThemedReactContext;
import com.matilock.mati_kyc_sdk.Mati;
import com.matilock.mati_kyc_sdk.MatiLoginButton;

import org.xmlpull.v1.XmlPullParser;

import javax.annotation.Nonnull;

import static com.samsung.android.sdk.camera.impl.internal.NativeUtil.TAG;

public class RNMatiVerifyManager extends SimpleViewManager {
    @Nonnull
    @Override
    public String getName() {
        return "RNMatiVerify";
    }

    @Nonnull
    @Override
    protected View createViewInstance(@Nonnull ThemedReactContext reactContext) {

        Mati.init(reactContext, "5c8a88fc0c43f7001bbab6b0");
        XmlPullParser parser = reactContext.getResources().getXml(R.xml.paths_provider);
        try {
            parser.next();
            parser.nextTag();
        } catch (Exception e) {
            e.printStackTrace();
        }

        AttributeSet attr = Xml.asAttributeSet(parser);
        Log.d("TAG", "User finished verification process successfully!");

        Toast.makeText(reactContext,"helloooo",Toast.LENGTH_LONG).show();
        return new MatiLoginButton(reactContext,attr);
    }
}
