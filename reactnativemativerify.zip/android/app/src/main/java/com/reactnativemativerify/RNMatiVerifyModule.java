package com.reactnativemativerify;

import android.widget.Toast;

import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;

import javax.annotation.Nonnull;

public class RNMatiVerifyModule extends ReactContextBaseJavaModule {
    public RNMatiVerifyModule(@Nonnull ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Nonnull
    @Override
    public String getName() {
        return "RNMatiVerify";
    }

    @ReactMethod
    public void show(String message){
        Toast.makeText(getReactApplicationContext(), message,Toast.LENGTH_LONG).show();
    }
}
